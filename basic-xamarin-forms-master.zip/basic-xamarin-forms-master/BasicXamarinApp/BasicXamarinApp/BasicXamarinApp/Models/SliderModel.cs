﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicXamarinApp.Models
{
    public class SliderModel
    {
        public int ID { get; set; }
        public string Uri { get; set; }
    }
}
