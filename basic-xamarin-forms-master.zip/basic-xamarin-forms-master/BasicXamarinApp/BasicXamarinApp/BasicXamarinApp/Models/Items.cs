﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicXamarinApp.Models
{
   public class Items
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        public bool Active { get; set; }
    }
}
